package edu.iteso.database;

public enum Datatype {
    Integer, Real, Text
}