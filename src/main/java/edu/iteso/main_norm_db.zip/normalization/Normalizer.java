package edu.iteso.normalization;

public interface Normalizer {

    Database normalize(Table table);

    NormalizerResult isNormalized(Table table);

}
