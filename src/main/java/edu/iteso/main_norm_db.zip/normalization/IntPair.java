package edu.iteso.normalization;
public class IntPair extends Pair<Integer, Integer> {

    public IntPair(int first, int second) {
        super(first, second);
    }

}
