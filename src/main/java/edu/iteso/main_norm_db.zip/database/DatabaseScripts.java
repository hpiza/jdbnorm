package edu.iteso.database;

import java.util.Map;

public class DatabaseScripts {

    private static final Map<String, DatabaseScript> instances =
            Map.of( "Mysql", new MysqlScript(),
                    "Mongodb", new MongodbScript(),
                    "Neo4j",  new MysqlScript(),
                    "CSV", new CsvFileDriver());

    public static DatabaseScript getMysql() {
        return instances.get("Mysql");
    }
    public static DatabaseScript getMongodb() {
        return instances.get("Mongodb");
    }

    public static DatabaseScript getNeo4j() { return instances.get("Neo4j"); }

    public static DatabaseScript getCSV() { return instances.get("CSV"); }
}
