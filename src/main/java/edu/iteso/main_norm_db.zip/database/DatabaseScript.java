package edu.iteso.database;

import edu.iteso.normalization.Database;

public interface DatabaseScript {
    void createDatabase(Database db, String name);

}
